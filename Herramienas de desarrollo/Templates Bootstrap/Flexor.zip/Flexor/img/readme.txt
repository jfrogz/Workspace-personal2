----------------------------
IMAGE DIRECTORY (/img)
----------------------------

This directory should contain all images used throughout the site.
Images within the root are used by css as background images.

----------------------------
SUB DIRECTORIES
----------------------------

All other images to within logical sub-directories related to the section of the site they appear in. Maintaining this structure is optionally but recommended.

----------------------------
RECOMMENDED IMAGES SIZES
----------------------------

Blog: 800px w x flexible h
Client logos: 120px w x 60px h
Showcase: 600px w × 330px h
Slides: flexible but same height is recommended
Team: 150px w x 150px
Quotes: 90px w x 140px h (with transparent background)