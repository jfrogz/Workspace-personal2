Animated Background Headers
=========

A collection of animated background header effects for your inspiration. We use Canvas and Javascript to create an animated background for large site headers.

[Article on Codrops](http://tympanus.net/codrops/?p=20153)

[Demo](http://tympanus.net/Development/AnimatedHeaderBackgrounds/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)

[© Codrops 2014](http://www.codrops.com)


